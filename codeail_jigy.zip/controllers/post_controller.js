// module.exports.actionName=function(req,res){}

module.exports.post = function(req,res){
    return res.end('<h1> post controller is up and running</h1>');
}